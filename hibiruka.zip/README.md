# ヒビルカ（個人用）設定手順書

予定を入れて「誰と？」で選んだ人に、**前の日の朝・当日の朝にLINEでお知らせ**するアプリです。

## しくみ（どこに何があるか）

| 役割 | 置き場所 |
|---|---|
| アプリの画面 | GitHub（pocham4173）の `hibiruka` リポジトリ → GitHub Pages |
| 予定・友だちのデータ | 個人用Firebase（会社の sekine-store とは別） |
| 毎朝のLINE送信 | GitHub Actions（同じリポジトリの中で自動実行・無料） |
| LINE | 今までのヒビルカ公式アカウント（@626hnkgo）をそのまま使う |

## ファイル

- `index.html` … アプリ本体（上の方の **CONFIG** だけ書き換える）
- `firestore.rules` … データを守るルール（Firebaseに貼る）
- `notify/send.js`, `notify/package.json` … 毎朝LINEを送るプログラム（さわらなくてOK）
- `.github/workflows/notify.yml` … 毎朝7時ごろに上のプログラムを動かす設定（さわらなくてOK）

---

## ① GitHub にリポジトリをつくる

1. pocham4173 でログインして、右上「＋」→「New repository」
2. 名前：`hibiruka`／**Public** を選んで「Create repository」
3. ファイルを入れる（Claudeに「入れて」と頼めば代わりに入れられます）
4. 「Settings」→「Pages」→ Branch を `main` / `(root)` にして Save
5. 数分後、`https://pocham4173.github.io/hibiruka/` で開けるようになります

## ② Firebase（個人用）をつくる

1. https://console.firebase.google.com で「プロジェクトを追加」→ 名前：`hibiruka`（アナリティクスはオフでOK）
2. **Webアプリを追加**（`</>` のマーク）→ 表示される `firebaseConfig` の6項目を、`index.html` の CONFIG → `firebase` に貼る
3. **Firestore Database** →「データベースを作成」→ 場所：`asia-northeast1（東京）` → 本番モード
4. Firestore の「ルール」タブに `firestore.rules` の中身を貼り、`ここにメールアドレス` を自分のメールに書き換えて「公開」
5. **Authentication** →「始める」→ ログイン方法で次の2つを有効にする
   - メール/パスワード
   - 匿名（友だちが招待を受け取るときに使います）
6. Authentication →「ユーザー」→「ユーザーを追加」で、自分のメールとパスワードを登録（アプリのログインに使います）
7. Authentication →「設定」→「承認済みドメイン」に `pocham4173.github.io` を追加
8. ⚙️「プロジェクトの設定」→「サービス アカウント」→「新しい秘密鍵を生成」→ JSONファイルがダウンロードされる（⑤で使う。**他の人に見せない**）

## ③ LINE の設定

LINE Developers（https://developers.line.biz/console/）にログインします。

**A. 送信用の鍵をもらう（Messaging API）**
1. ヒビルカ公式アカウント（@626hnkgo）が入っている**プロバイダー**を開く
   - 見当たらない場合：LINE Official Account Manager →「設定」→「Messaging API」→「利用する」で有効化すると、ここに出てきます
2. そのチャネルの「Messaging API設定」タブ →「チャネルアクセストークン（長期）」→「発行」→ コピー（⑤で使う）

**B. 招待リンク用の LIFF をつくる**
1. **Aと同じプロバイダー**の中で「新規チャネル作成」→「LINEログイン」
   - アプリタイプ：「ウェブアプリ」
   - ⚠️ 必ず同じプロバイダーにしてください（違うとお知らせが届きません）
2. 「チャネル基本設定」→「リンクされたLINE公式アカウント」で ヒビルカ を選ぶ
3. 「LIFF」タブ →「追加」
   - LIFFアプリ名：ヒビルカ
   - サイズ：Full
   - エンドポイントURL：`https://pocham4173.github.io/hibiruka/`
   - Scope：`profile` と `openid` にチェック
   - 友だち追加オプション：**On (Aggressive)**（受け取るときに友だち追加もまとめて出ます）
4. できた **LIFF ID**（`2001234567-AbCdEfGh` のような形）を、`index.html` の CONFIG → `liffId` に貼る
5. LINEログインチャネルの上の方にある「**開発中**」を「**公開**」に切り替える
   - ⚠️ これを忘れると、自分以外の人が招待を開けません

**C. 前のヒビルカを止める**
- Messaging API設定の「Webhook URL」が前のアプリ（chatgpt.site）のままなら、「Webhookの利用」をオフにしておくと安心です
- 前のアプリで入れた予定の通知が重ならないよう、前のアプリの予定は消しておいてください

## ④ index.html を仕上げる

CONFIG の3か所を書き換えて、GitHub に上書きアップロードします。
- `firebase` … ②-2 の6項目
- `liffId` … ③-B-4
- `ownerName` … 招待画面に出る名前（今は「理絵」）

## ⑤ GitHub に鍵を登録する

リポジトリの「Settings」→「Secrets and variables」→「Actions」→「New repository secret」で2つ登録します。

| Name | Secret（中身） |
|---|---|
| `FIREBASE_SERVICE_ACCOUNT` | ②-8 のJSONファイルを開いて、**中身を全部**コピーして貼る |
| `LINE_CHANNEL_ACCESS_TOKEN` | ③-A-2 のトークン |

## ⑥ 使ってみる

1. `https://pocham4173.github.io/hibiruka/` を開いてログイン
2. 「👥 友だち」で **「自分」** という名前で招待をつくり、「LINEで招待を送る」→ 自分のトーク（Keepメモなど）に送って自分で開く →「受け取る」
3. 同じように家族や友だちを招待
4. 「✏️ 予定を入れる」で明日の予定を入れ、「誰と？」で自分を選んで保存
5. テスト：GitHub の「Actions」→「予定のLINE通知」→「Run workflow」→ 数十秒後にLINEが届けば成功！

iPhoneのホーム画面に置くときは、Safariで開いて 共有ボタン →「ホーム画面に追加」。

---

## 知っておくこと

- **LINEの無料プランは月200通まで**。1回のお知らせ×人数で数えます（例：3人に前日・当日＝6通）
- お知らせは**毎朝7時ごろ**に1回。朝7時を過ぎてから入れた「今日の予定」は通知されません
- 予定の日付を直すと、お知らせはもう一度送られます
- GitHub は、リポジトリを**60日間さわらないと毎朝の自動実行を止めます**。止まるとメールが来るので、Actions の画面で「Enable workflow」を押せば再開します
- 友だちに届くのは、その人を選んだ予定のお知らせだけです（他の予定・メモ帳全体は見えません）
