// ヒビルカ：毎朝、予定のお知らせをLINEで送るプログラム
// GitHub Actions から毎朝自動で動きます（.github/workflows/notify.yml）

const admin = require("firebase-admin");

const serviceAccount = JSON.parse(process.env.FIREBASE_SERVICE_ACCOUNT || "{}");
const LINE_TOKEN = process.env.LINE_CHANNEL_ACCESS_TOKEN;
if (!serviceAccount.project_id || !LINE_TOKEN) {
  console.error("GitHubのSecretsに FIREBASE_SERVICE_ACCOUNT と LINE_CHANNEL_ACCESS_TOKEN を登録してください。");
  process.exit(1);
}

admin.initializeApp({ credential: admin.credential.cert(serviceAccount) });
const db = admin.firestore();

const WEEK = "日月火水木金土";
// 日本時間で「今日から◯日後」の日付（YYYY-MM-DD）
function jstDate(offsetDays) {
  const d = new Date(Date.now() + 9 * 3600 * 1000 + offsetDays * 86400 * 1000);
  return d.toISOString().slice(0, 10);
}
function fmtDate(s) {
  const [y, m, d] = s.split("-").map(Number);
  const w = new Date(Date.UTC(y, m - 1, d)).getUTCDay();
  return `${m}月${d}日(${WEEK[w]})`;
}

function buildText(ev, isToday) {
  const lines = [
    isToday ? "🔔 今日の予定のお知らせ" : "🔔 明日の予定のお知らせ",
    "",
    `📅 ${fmtDate(ev.date)}${ev.time ? " " + ev.time : ""}`,
    `✏️ ${ev.title}`,
  ];
  if (ev.place) lines.push(`📍 ${ev.place}`);
  if (ev.memo) lines.push(`📝 ${ev.memo}`);
  lines.push("", "ヒビルカより");
  return lines.join("\n");
}

async function sendLine(userIds, text) {
  const res = await fetch("https://api.line.me/v2/bot/message/multicast", {
    method: "POST",
    headers: { "Content-Type": "application/json", Authorization: `Bearer ${LINE_TOKEN}` },
    body: JSON.stringify({ to: userIds, messages: [{ type: "text", text }] }),
  });
  if (!res.ok) throw new Error(`LINE送信エラー ${res.status}: ${await res.text()}`);
}

async function main() {
  const today = jstDate(0);
  const tomorrow = jstDate(1);
  console.log(`今日: ${today} / 明日: ${tomorrow}`);

  const friends = new Map();
  (await db.collection("friends").get()).forEach(d => friends.set(d.id, d.data()));

  const snap = await db.collection("events").where("date", "in", [today, tomorrow]).get();
  let sent = 0, failed = 0;

  for (const doc of snap.docs) {
    const ev = doc.data();
    const isToday = ev.date === today;
    const want = isToday ? ev.notifyDay : ev.notifyPrev;
    const sentKey = isToday ? "sentDay" : "sentPrev";
    if (!want || ev[sentKey]) continue;

    const userIds = [...new Set(
      (ev.friendIds || [])
        .map(id => friends.get(id))
        .filter(f => f && f.status === "joined" && f.lineUserId)
        .map(f => f.lineUserId)
    )];
    if (!userIds.length) continue;

    try {
      await sendLine(userIds, buildText(ev, isToday));
      await doc.ref.update({ [sentKey]: true });
      sent++;
      console.log(`送信OK: ${ev.date}「${ev.title}」→ ${userIds.length}人`);
    } catch (e) {
      failed++;
      console.error(`送信失敗: ${ev.date}「${ev.title}」`, e.message);
    }
  }

  console.log(`完了：送信 ${sent}件 / 失敗 ${failed}件`);
  if (failed) process.exit(1);
}

main().catch(e => { console.error(e); process.exit(1); });
